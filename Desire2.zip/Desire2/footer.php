<footer>
    <img style="display:inline;" src="http://desireinteriors.in/wp-content/uploads/2020/02/desire-interior-logo.png" alt="logo" class="logo">
    <p style="color:grey;">Developed by DMC 2023</p>
</footer>